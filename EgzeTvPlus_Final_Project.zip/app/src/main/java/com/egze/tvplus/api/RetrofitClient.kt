package com.egze.tvplus.api

import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

object RetrofitClient {
    // Change to your domain if needed
    private const val BASE = "https://egze.org/"

    val api: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE)
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}
