package com.egze.tvplus.data

import com.egze.tvplus.model.Channel

object ChannelsRepository {
    // populated by ChannelsFragment after API call
    var channels: List<Channel> = emptyList()
}
