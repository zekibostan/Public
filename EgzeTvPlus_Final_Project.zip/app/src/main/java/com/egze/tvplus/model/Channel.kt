package com.egze.tvplus.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Channel(
    val id: String,
    val title: String,
    val thumbImg: String,
    val url: String,
    val description: String,
    val platform_android: String
) : Parcelable
