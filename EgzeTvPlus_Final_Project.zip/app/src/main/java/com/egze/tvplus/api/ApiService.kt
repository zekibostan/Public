package com.egze.tvplus.api

import com.egze.tvplus.model.Channel
import com.squareup.moshi.JsonClass
import retrofit2.http.GET

@JsonClass(generateAdapter = true)
data class ChannelsResponse(
    val status: String,
    val updated_at: String,
    val channels: List<Channel>
)

interface ApiService {
    @GET("tv/app-api/channels.php")
    suspend fun getChannels(): ChannelsResponse
}
