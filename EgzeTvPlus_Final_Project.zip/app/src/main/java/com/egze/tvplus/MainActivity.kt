package com.egze.tvplus

import android.os.Bundle
import androidx.fragment.app.FragmentActivity

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val frag = ChannelsFragment()
        supportFragmentManager.beginTransaction()
            .replace(android.R.id.content, frag)
            .commit()
    }
}
