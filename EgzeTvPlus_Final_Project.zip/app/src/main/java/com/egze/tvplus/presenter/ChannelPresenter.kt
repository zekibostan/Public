package com.egze.tvplus.presenter

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.leanback.widget.Presenter
import com.bumptech.glide.Glide
import com.egze.tvplus.model.Channel

class ChannelPresenter(private val context: Context) : Presenter() {
    override fun onCreateViewHolder(parent: ViewGroup): ViewHolder {
        val container = FrameLayout(context)
        container.layoutParams = ViewGroup.LayoutParams(360, 220)

        val iv = ImageView(context)
        iv.layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 180)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        container.addView(iv)

        val title = TextView(context)
        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = 182
        title.layoutParams = lp
        title.setSingleLine(true)
        container.addView(title)
        return ViewHolder(container)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, item: Any) {
        val channel = item as Channel
        val container = viewHolder.view as FrameLayout
        val iv = container.getChildAt(0) as ImageView
        val title = container.getChildAt(1) as TextView
        val thumb = "https://egze.org/tv/images/thumbnail_images/${channel.thumbImg}"
        Glide.with(context).load(thumb).centerCrop().into(iv)
        title.text = channel.title
        iv.contentDescription = channel.title
    }

    override fun onUnbindViewHolder(viewHolder: ViewHolder) {}
}
