package com.egze.tvplus

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class SearchActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Host the SearchFragment
        supportFragmentManager.beginTransaction()
            .replace(android.R.id.content, ChannelsSearchFragment())
            .commit()
    }
}
