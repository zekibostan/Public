package com.egze.tvplus

import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.egze.tvplus.data.ChannelsRepository
import com.egze.tvplus.model.Channel
import com.bumptech.glide.Glide
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.ui.PlayerView
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class PlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private var hideJob: Job? = null
    private lateinit var overlay: View
    private lateinit var ivLogo: ImageView
    private lateinit var tvTitle: TextView
    private lateinit var tvDesc: TextView

    private var currentIndex = 0
    private val channels get() = ChannelsRepository.channels

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        overlay = findViewById(R.id.overlay)
        ivLogo = findViewById(R.id.ivLogo)
        tvTitle = findViewById(R.id.tvTitle)
        tvDesc = findViewById(R.id.tvDesc)

        currentIndex = intent.getIntExtra("channel_index", 0)
        if (channels.isEmpty() || currentIndex < 0 || currentIndex >= channels.size) {
            finish()
            return
        }
        playChannel(channels[currentIndex])
        showOverlayTemp()
    }

    private fun playChannel(channel: Channel) {
        tvTitle.text = channel.title
        tvDesc.text = channel.description
        val thumb = "https://egze.org/tv/images/thumbnail_images/${channel.thumbImg}"
        Glide.with(this).load(thumb).into(ivLogo)
        if (player == null) {
            player = ExoPlayer.Builder(this).build()
            val playerView = findViewById<PlayerView>(R.id.player_view)
            playerView.player = player
        } else {
            player?.stop()
            player?.clearMediaItems()
        }
        val media = MediaItem.fromUri(channel.url)
        player?.setMediaItem(media)
        player?.prepare()
        player?.playWhenReady = true
    }

    private fun showOverlayTemp() {
        overlay.alpha = 1f
        overlay.visibility = View.VISIBLE
        hideJob?.cancel()
        hideJob = lifecycleScope.launch {
            delay(3000)
            overlay.animate().alpha(0f).withEndAction { overlay.visibility = View.GONE }
        }
    }

    private fun switchChannel(delta: Int) {
        val size = channels.size
        if (size == 0) return
        currentIndex = (currentIndex + delta + size) % size
        playChannel(channels[currentIndex])
        showOverlayTemp()
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                overlay.alpha = 1f
                overlay.visibility = View.VISIBLE
                showOverlayTemp()
                return true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                switchChannel(1)
                return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                switchChannel(-1)
                return true
            }
            KeyEvent.KEYCODE_BACK -> {
                finish()
                return true
            }
        }
        return super.onKeyUp(keyCode, event)
    }

    override fun onStop() {
        super.onStop()
        player?.release()
        player = null
    }
}
