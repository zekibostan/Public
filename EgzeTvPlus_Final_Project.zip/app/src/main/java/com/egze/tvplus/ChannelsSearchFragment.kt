package com.egze.tvplus

import androidx.leanback.app.SearchSupportFragment
import androidx.leanback.widget.ArrayObjectAdapter
import androidx.leanback.widget.HeaderItem
import androidx.leanback.widget.ListRow
import androidx.leanback.widget.ListRowPresenter
import androidx.leanback.widget.Presenter
import android.content.Intent
import android.os.Bundle
import android.util.Log
import com.egze.tvplus.data.ChannelsRepository
import com.egze.tvplus.presenter.ChannelPresenter
import com.egze.tvplus.model.Channel

class ChannelsSearchFragment : SearchSupportFragment(), SearchSupportFragment.SearchResultProvider {

    private val rowsAdapter = ArrayObjectAdapter(ListRowPresenter())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        searchResultProvider = this
        // optional hint
        setSearchAffordanceColor(0xFF0D47A1.toInt())
    }

    override fun getResultsAdapter(): ArrayObjectAdapter {
        return rowsAdapter
    }

    override fun onQueryTextChange(newQuery: String?): Boolean {
        val q = newQuery?.trim() ?: ""
        updateResults(q)
        return true
    }

    override fun onQueryTextSubmit(query: String?): Boolean {
        updateResults(query ?: "")
        return true
    }

    private fun updateResults(q: String) {
        rowsAdapter.clear()
        if (q.isEmpty()) return
        try {
            val all = ChannelsRepository.channels
            val filtered = all.filter { it.title.contains(q, ignoreCase=true) }
            val presenter: Presenter = ChannelPresenter(requireContext())
            val rowAdapter = ArrayObjectAdapter(presenter)
            filtered.forEach { rowAdapter.add(it) }
            if (filtered.isNotEmpty()) {
                rowsAdapter.add(ListRow(HeaderItem("Arama Sonuçları"), rowAdapter))
            }
        } catch (ex: Exception) {
            Log.e("ChannelsSearch", "Search error: ${ex.message}")
        }
    }

    override fun onItemClicked(item: Any?) {
        if (item is Channel) {
            val intent = Intent(requireContext(), PlayerActivity::class.java)
            val index = ChannelsRepository.channels.indexOfFirst { it.id == item.id }
            intent.putExtra("channel_index", index)
            startActivity(intent)
        }
    }
}
