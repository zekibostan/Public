package com.egze.tvplus

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.leanback.app.BrowseSupportFragment
import androidx.leanback.widget.ArrayObjectAdapter
import androidx.leanback.widget.HeaderItem
import androidx.leanback.widget.ListRow
import androidx.leanback.widget.ListRowPresenter
import com.egze.tvplus.api.RetrofitClient
import com.egze.tvplus.data.ChannelsRepository
import com.egze.tvplus.presenter.ChannelPresenter
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.launch

class ChannelsFragment : BrowseSupportFragment() {

    private val rowsAdapter = ArrayObjectAdapter(ListRowPresenter())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "EgzeTv+"
        headersState = HEADERS_DISABLED
        adapter = rowsAdapter

        setOnSearchClickedListener {
            // Open SearchActivity (Leanback Search)
            val intent = Intent(requireContext(), SearchActivity::class.java)
            ContextCompat.startActivity(requireContext(), intent, null)
        }

        fetchChannels()
    }

    private fun fetchChannels() {
        val handler = CoroutineExceptionHandler { _, ex ->
            Log.e("ChannelsFragment", "API error: ${ex.message}")
        }
        lifecycleScope.launch(handler) {
            val resp = RetrofitClient.api.getChannels()
            val channels = resp.channels.filter { it.platform_android == "1" }
            ChannelsRepository.channels = channels
            val grouped = channels.groupBy { it.description ?: "Diğer" }
            val cardPresenter = ChannelPresenter(requireContext())
            rowsAdapter.clear()
            for ((category, list) in grouped) {
                val header = HeaderItem(category)
                val listRowAdapter = ArrayObjectAdapter(cardPresenter)
                list.forEach { listRowAdapter.add(it) }
                rowsAdapter.add(ListRow(header, listRowAdapter))
            }
        }
    }

    override fun onResume() {
        super.onResume()
        setOnItemViewClickedListener { itemViewHolder, item, rowViewHolder, row ->
            if (item is com.egze.tvplus.model.Channel) {
                val intent = android.content.Intent(requireContext(), PlayerActivity::class.java)
                val index = ChannelsRepository.channels.indexOfFirst { it.id == item.id }
                intent.putExtra("channel_index", index)
                startActivity(intent)
            }
        }
    }
}
