EgzeTv+ Android TV - Final Project
---------------------------------

What is included:
- Leanback category rows (ChannelsFragment)
- Search (Leanback SearchSupportFragment)
- PlayerActivity with ExoPlayer, overlay and DPAD prev/next
- Global ChannelsRepository stores fetched channels
- Retrofit client configured to https://egze.org/

How to build:
1. Open this folder in Android Studio.
2. Let Gradle sync. If prompted, install SDK/Plugin versions.
3. Update `app/src/main/java/com/egze/tvplus/api/RetrofitClient.kt` BASE if your API is at a different domain.
4. Run on an Android TV device or Android TV emulator.
5. To build signed APK: Build -> Generate Signed Bundle / APK.

Icon source path included in project (copied into mipmap-anydpi-v26):
/mnt/data/A_flat_design_digital_vector_graphic_icon_for_Egze.png

Notes:
- The app expects the API JSON format you provided.
- Thumbnails are loaded from: https://egze.org/tv/images/thumbnail_images/{thumbImg}
- If you want remote text-entry search optimized for TV, Leanback's SearchSupportFragment works with DPAD input.
